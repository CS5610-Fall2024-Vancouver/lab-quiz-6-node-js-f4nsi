const express = require('express');
const router = express.Router();

let users = [
  { id: 1, name: 'Alice' },
  { id: 2, name: 'Bob' },
];

router.get('/', (req, res) => {
  res.json(users);
});


router.get('/:id', (req, res) => {
  // TODO: Find a user with a specific ID
  // Use req.params to access the user ID from the URL.
  const userId = parseInt(req.params.id);
  // Search through the users array to find the user with the matching ID.
  const user = users.find(u => u.id === userId);
  // If the user is found, respond with the user data in JSON format.
  if (user) {
    res.json(user);
  } else {
    res.status(404).json({error: 'User not found'});
  }
  // If the user is not found, respond with a 404 status code and an appropriate error message.
});


router.post('/', (req, res) => {
  // TODO: Create new users
  // Use req.body to get the user's name from the request body.
  // Create a new user object with:
  // A unique ID
  // A name: Get this from req.body.name.
  const user = {
    id: users.length + 1,
    name: req.body.name};
  // Add the new user to the users array.
  users.push(user);
  // Respond with a status code of 201 and return the newly created user in JSON format.
  res.status(201).json(user);
  });

router.delete('/:id', (req, res) => {
  // TODO: Delete a user with a specific ID
  // Use req.params to get the user ID from the URL.
  const userId = parseInt(req.params.id);
  const before = users.length;
  // Use filter() to remove the user with the matching ID from the users array.
  users = users.filter(u => u.id !== userId);
  // Respond with a status code of 204 to indicate that the deletion was successful (no content to return).
  const after = users.length;
  if (before < after) {
    res.status(204).send();
  } else {
    res.status(404).json({error: 'User not found.'});
  }
});

module.exports = router;
