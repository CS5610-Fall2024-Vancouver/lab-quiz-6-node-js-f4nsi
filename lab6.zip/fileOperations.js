const { rejects } = require('assert');
const { error } = require('console');
const fs = require('fs');
const { resolve } = require('path');

const writeFilePromise = () => { // the promise of writing the file
    return new Promise((resolve, rejects) => {
        fs.writeFile('userData.txt', 'Hello, this is a test message!', (err) => {
            if (err) {
                rejects(err); // promise rejected if there's an error
            } else {
                resolve("Success!"); // promise resolved if data is written successfully
            }
        });
    });
};

const readFilePromise = () => { // the promise of reading the file
    return new Promise((resolve, rejects) => {
        fs.readFile('userData.txt', 'utf-8', (err, data) => {
            if (err) {
                rejects(err); // promise rejected if there's an error
            } else {
                resolve(data); // promise resolved if data is read successfully
            }
        });
    });
};

writeFilePromise()
    .then((message) => {
        console.log(message); // print the success message
        return readFilePromise();
    })
    .then((result) => {
        console.log("Data:", result); // print the data
    })
    .catch((err) => {
        console.log("Error:", err); // print the possible errors
    })